package com.armandgray.taap.db;

public class CursorDataHelperTest {

}