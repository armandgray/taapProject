package com.armandgray.shared.application;

import com.armandgray.shared.viewModel.PercentageRateViewModel;

public interface TAAPAppComponent {

    void inject(PercentageRateViewModel viewModel);
}
