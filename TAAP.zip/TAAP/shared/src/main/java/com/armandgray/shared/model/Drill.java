package com.armandgray.shared.model;

public class Drill {

    private final String title;

    public Drill(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}
