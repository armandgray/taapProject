package com.armandgray.taap.navigation;

import org.junit.Test;

public class DestinationTest {

    @Test
    public void testGetDestination() {
        // TODO Implement Tests
    }
}